## Modelo Cynefin

![](img/Pasted%20image%2020240910160909.png)



> [!NOTE] Ceremonias
> La agilidad de un equipo se construye sobre prácticas de ingeniería, un enfoque estratégico hacia el desarrollo y el cambio, y una gran colaboración en equipo. Las ceremonias ágiles facilitan la comunicación entre los miembros del equipo y promueven una comprensión compartida de lo que se está construyendo dentro de un sprint.

![](img/Pasted%20image%2020240910161535.png)