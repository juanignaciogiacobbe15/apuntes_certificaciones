# Agilidad
- NO es una metodología -> No es algo que pretenda indicarnos qué hacer paso a paso.
- NO es ir más rápido -> Aunque entregar valor temprano sí es una de las promesas ágiles.
- NO es multitasking -> Aunque implique gestionar un contexto complejo, incierto y cambiante.
- Es una forma de hacer -> Que nos invita a experimentar y aprender en pasos pequeños.