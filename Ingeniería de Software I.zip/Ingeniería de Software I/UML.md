# Unified Modeling Language(UML)
- Es una forma de representar visualmente la arquitectura y diseño de sistemas de software complejos.
- Facilita la comprensión de ideas y sistemas complejos mediante la visualización.

	![](img/Pasted%20image%2020240910150750.png)