# ¿Por qué necesitamos un buen Diseño?
- Para manejar el cambio.
- Para tener un delivery rápido.
- Para lidiar con la complejidad.

# Principios SOLID
- [03A-Single Responsibility Principle](03A-Single%20Responsibility%20Principle.md)
- 